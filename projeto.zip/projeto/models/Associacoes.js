import { Usuario } from "./Usuario.js";
import { Veiculo } from "./Veiculo.js";
import { RegistroAcesso } from "./RegistroAcesso.js";

// Um usuário pode ter vários veículos
Usuario.hasMany(Veiculo);
Veiculo.belongsTo(Usuario);

// Um veículo pode ter vários acessos
Veiculo.hasMany(RegistroAcesso);
RegistroAcesso.belongsTo(Veiculo);