import { database } from "../database.js";
import { DataTypes } from "sequelize";

const Veiculo = database.define('Veiculo', {
    id: {
        primaryKey: true,
        autoIncrement: true,
        type: DataTypes.INTEGER
    }, 
    placa: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true
    },
    modelo: {
        type: DataTypes.STRING
    },
    cor: {
        type: DataTypes.STRING
    }
})

export { Veiculo }