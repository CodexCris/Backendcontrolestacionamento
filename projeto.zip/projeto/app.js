import express from 'express'
import 'dotenv/config'
import { router } from './rotas/usuario.js'
import { routerAcesso } from './rotas/acesso.js'
import { routerVeiculo } from "./rotas/veiculo.js"
import './models/Associacoes.js'
import { database } from './database.js'
import cors from "cors"

const app = express()

const origens = ['http://localhost:5173'] 
app.use(cors({ origin: origens })) 

app.use(express.json())
app.use(router)
app.use(routerAcesso)
app.use(routerVeiculo)
await database.sync({ alter: true })

app.listen(3000, () => console.log('servidor rodando'))
