import jwt from 'jsonwebtoken';
const segredoJwt = process.env.SEGREDO_JWT;

const validarToken = (req, res, next) => {
  try {
    const { token } = req.headers;
    if (!token) {
      return res.status(401).send({ mensagem: 'Token não fornecido' });
    }

    const conteudoDoToken = jwt.verify(token, segredoJwt);
    req.usuario = conteudoDoToken;

    next();
  } catch (erro) {
    res.status(403).send({ mensagem: 'Token inválido' });
  }
};

export { validarToken };