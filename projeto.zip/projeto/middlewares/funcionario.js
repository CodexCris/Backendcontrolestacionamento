export const autorizarFuncionario = (req, res, next) => {
  const { funcionario } = req.usuario;

  if (!funcionario) {
    return res.status(403).json({ mensagem: 'Acesso permitido apenas a funcionários' });
  }

  next();
};
