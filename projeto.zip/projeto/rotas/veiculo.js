import express from 'express';
import { cadastrarVeiculo, listarVeiculos, listarMeusVeiculos } from '../controllers/veiculo.js';
import { validarToken } from '../middlewares/usuario.js';
import { autorizarFuncionario } from '../middlewares/funcionario.js';
const routerVeiculo = express.Router();

routerVeiculo.post('/veiculo', validarToken, cadastrarVeiculo); // Qualquer usuário
routerVeiculo.get('/veiculo', validarToken, autorizarFuncionario, listarVeiculos); // Só funcionário
routerVeiculo.get('/meus-veiculos', validarToken, listarMeusVeiculos);

export { routerVeiculo };
