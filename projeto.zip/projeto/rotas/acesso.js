import express from 'express';
import { registrarEntrada, registrarSaida, listaAcessos } from '../controllers/acesso.js';
import { validarToken } from '../middlewares/usuario.js';
import { autorizarFuncionario } from '../middlewares/funcionario.js';
const routerAcesso = express.Router();

routerAcesso.post('/entrada', validarToken, autorizarFuncionario, registrarEntrada);
routerAcesso.post('/saida', validarToken, autorizarFuncionario, registrarSaida);
routerAcesso.get('/historico', validarToken, autorizarFuncionario, listaAcessos);

export { routerAcesso };
