import { Veiculo } from "../models/Veiculo.js";
import { Usuario } from "../models/Usuario.js";

const cadastrarVeiculo = async (req, res) => {
  try {
    const { placa, modelo, cor, usuarioId } = req.body;

    if (!placa || !usuarioId) {
      return res.status(400).json({ mensagem: "Dados incompletos" });
    }

    const veiculoExistente = await Veiculo.findOne({ where: { placa } });
    if (veiculoExistente) {
      return res.status(400).json({ mensagem: "Placa já cadastrada" });
    }

    const novoVeiculo = await Veiculo.create({ placa, modelo, cor, UsuarioId: usuarioId });
    return res.status(201).json(novoVeiculo);
  } catch (erro) {
    return res.status(500).json({ mensagem: "Erro ao cadastrar veículo" });
  }
};

const listarVeiculos = async (req, res) => {
  try {
    const veiculos = await Veiculo.findAll({ include: Usuario });
    return res.json(veiculos);
  } catch (erro) {
    return res.status(500).json({ mensagem: "Erro ao listar veículos" });
  }
};

const listarMeusVeiculos = async (req, res) => {
  try {
    const meusVeiculos = await Veiculo.findAll({
      where: { UsuarioId: req.usuario.idUsuario }
    });
    return res.json(meusVeiculos);
  } catch (erro) {
    console.error(erro);
    return res.status(500).json({ mensagem: "Erro ao listar seus veículos" });
  }
};


export { cadastrarVeiculo, listarVeiculos, listarMeusVeiculos };
