
import { RegistroAcesso } from '../models/RegistroAcesso.js';
import { Veiculo } from '../models/Veiculo.js';

const registrarEntrada = async (req, res) => {
  try {
    const { placa } = req.body;

    const veiculo = await Veiculo.findOne({ where: { placa } });
    if (!veiculo) return res.status(404).json({ error: 'Veículo não encontrado' });

    const entrada = await RegistroAcesso.create({
      horario_entrada: new Date(),
      VeiculoId: veiculo.id
    });

    const entradaConvertida = {
      ...entrada.toJSON(),
      horario_entrada: new Date(entrada.horario_entrada).toLocaleString("pt-BR", {
        timeZone: "America/Sao_Paulo"
      })
    };

    return res.json(entradaConvertida);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Erro ao registrar entrada' });
  }
};

const registrarSaida = async (req, res) => {
  try {
    const { placa } = req.body;

    const veiculo = await Veiculo.findOne({ where: { placa } });
    if (!veiculo) return res.status(404).json({ error: 'Veículo não encontrado' });

    const ultimoAcesso = await RegistroAcesso.findOne({
      where: { VeiculoId: veiculo.id, horario_saida: null },
      order: [['createdAt', 'DESC']]
    });

    if (!ultimoAcesso) return res.status(400).json({ error: 'Nenhuma entrada registrada' });

    ultimoAcesso.horario_saida = new Date();
    await ultimoAcesso.save();

    const saidaConvertida = {
      ...ultimoAcesso.toJSON(),
      horario_entrada: new Date(ultimoAcesso.horario_entrada).toLocaleString("pt-BR", {
        timeZone: "America/Sao_Paulo"
      }),
      horario_saida: new Date(ultimoAcesso.horario_saida).toLocaleString("pt-BR", {
        timeZone: "America/Sao_Paulo"
      })
    };

    return res.json(saidaConvertida);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Erro ao registrar saída' });
  }
};

const listaAcessos = async (req, res) => {
  try {
    const acessos = await RegistroAcesso.findAll({
      include: ['Veiculo'],
      order: [['createdAt', 'DESC']]
    });

    const acessosConvertidos = acessos.map(acesso => {
      const dados = acesso.toJSON();

      return {
        ...dados,
        horario_entrada: dados.horario_entrada
          ? new Date(dados.horario_entrada).toLocaleString("pt-BR", {
              timeZone: "America/Sao_Paulo"
            })
          : null,
        horario_saida: dados.horario_saida
          ? new Date(dados.horario_saida).toLocaleString("pt-BR", {
              timeZone: "America/Sao_Paulo"
            })
          : null
      };
    });

    return res.json(acessosConvertidos);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Erro ao listar acessos' });
  }
};

export { registrarEntrada, registrarSaida, listaAcessos };
